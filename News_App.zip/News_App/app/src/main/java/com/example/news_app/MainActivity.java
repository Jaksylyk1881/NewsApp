package com.example.news_app;

import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;

import android.widget.EditText;
import android.widget.TextView;

import java.io.IOException;
import java.net.URL;

import static com.example.news_app.utils.NetworkUtils.generalURL;
import static com.example.news_app.utils.NetworkUtils.getResponseFromURL;


public class MainActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
//        result = findViewById(R.id.filmTitle);
//        search = findViewById(R.id.searchView);
    }


//    TextView result;
//    EditText search;
//
//
//
//    class FilmQuery extends AsyncTask<URL, Void, String>{
//
//        @Override
//        protected String doInBackground(URL... urls) {
//
//            String response = null;
//            try {
//                response = getResponseFromURL(urls[0]);
//            } catch (IOException e) {
//                e.printStackTrace();
//            }
//            return response;
//
//        }
//        @Override
//        protected void onPostExecute(String response){
//            result.setText(response);
//        }
//    }
//
//
//
//    public void Onclick(View view){
//        URL generatedURL = generalURL("550");
//        new FilmQuery().execute(generatedURL);
//    }
}