 package com.example.news_app;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.news_app.model.Films;

import java.util.List;

 public class FilmAdapter extends RecyclerView.Adapter<FilmAdapter.MyViewHolder> {


    private Context mContext;
    private List<Films> mDate;

     public FilmAdapter(Context mContext, List<Films> mDate) {
         this.mContext = mContext;
         this.mDate = mDate;
     }
     @NonNull
     @Override
     public MyViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
         View v;
         LayoutInflater inflater = LayoutInflater.from(mContext);
         v = inflater.inflate(R.layout.films_item, viewGroup,  false);
         return new MyViewHolder(v);
     }

     @Override
     public void onBindViewHolder(@NonNull FilmAdapter.MyViewHolder holder, int position) {

         holder.filmTitle.setText(mDate.get(position).getFilmTitle());
         holder.filmDate.setText(mDate.get(position).getFilmDate());
         holder.filmRate.setText(mDate.get(position).getFilmRating());




     }

     @Override
     public int getItemCount() {
         return 0;
     }


     public static class MyViewHolder extends RecyclerView.ViewHolder{

         TextView filmTitle;
         TextView filmDate;
         TextView filmRate;
         ImageView filmImage;

         public MyViewHolder(@NonNull View itemView) {
             super(itemView);
             filmDate = itemView.findViewById(R.id.filmDate);
             filmTitle = itemView.findViewById(R.id.filmTitle);
             filmRate = itemView.findViewById(R.id.filmRate);
             filmImage = itemView.findViewById(R.id.filmImage);

         }
     }

}
